#' caustests: Multiple Granger Causality Tests
#'
#' Comprehensive suite of Granger causality tests including standard
#' Toda-Yamamoto, Fourier-based tests with single and cumulative frequencies,
#' and quantile causality tests with bootstrap inference.
#'
#' @section Main Function:
#' \itemize{
#'   \item \code{\link{caustests}}: Perform Granger causality tests
#' }
#'
#' @section Available Tests:
#' \enumerate{
#'   \item Toda-Yamamoto (1995) - Robust to integration order
#'   \item Single Fourier Granger (Enders & Jones, 2016)
#'   \item Single Fourier Toda-Yamamoto (Nazlioglu et al., 2016)
#'   \item Cumulative Fourier Granger (Enders & Jones, 2019)
#'   \item Cumulative Fourier Toda-Yamamoto (Nazlioglu et al., 2019)
#'   \item Quantile Toda-Yamamoto (Cai et al., 2023)
#'   \item Bootstrap Fourier Granger in Quantiles (Cheng et al., 2021)
#' }
#'
#' @section Data:
#' \itemize{
#'   \item \code{\link{caustests_data}}: Example time series dataset
#' }
#'
#' @references
#' Toda, H. Y., & Yamamoto, T. (1995). Statistical inference in vector 
#' autoregressions with possibly integrated processes. \emph{Journal of 
#' Econometrics}, 66(1-2), 225-250. \doi{10.1016/0304-4076(94)01616-8}
#'
#' Enders, W., & Jones, P. (2016). Grain prices, oil prices, and multiple 
#' smooth breaks in a VAR. \emph{Studies in Nonlinear Dynamics & Econometrics},
#' 20(4), 399-419. \doi{10.1515/snde-2015-0004}
#'
#' Nazlioglu, S., Gormus, N. A., & Soytas, U. (2016). Oil prices and real 
#' estate investment trusts (REITs): Gradual-shift causality and volatility 
#' transmission analysis. \emph{Energy Economics}, 60, 168-175. 
#' \doi{10.1016/j.eneco.2016.09.009}
#'
#' Nazlioglu, S., Soytas, U., & Gormus, N. A. (2019). Oil prices and monetary 
#' policy in emerging markets: Structural shifts in causal linkages. 
#' \emph{Emerging Markets Finance and Trade}, 55(1), 105-117. 
#' \doi{10.1080/1540496X.2017.1402843}
#'
#' Cai, Y., Chang, T., Xiang, Y., & Chang, H. L. (2023). Testing Granger 
#' causality in quantiles between the stock and the foreign exchange markets 
#' of Japan. \emph{Finance Research Letters}, 58, 104327. 
#' \doi{10.1016/j.frl.2023.104327}
#'
#' Cheng, S. C., Hsueh, H. P., Ranjbar, O., Wang, M. C., & Chang, T. (2021). 
#' Bootstrap Fourier Granger causality test in quantiles and the asymmetric 
#' causal relationship between CO2 emissions and economic growth. 
#' \emph{Letters in Spatial and Resource Sciences}, 14, 31-49. 
#' \doi{10.1007/s12076-020-00256-3}
#'
#' @docType package
#' @name caustests-package
#' @aliases caustests-package
#' @keywords internal
"_PACKAGE"
